package com.sha3wza.ajztracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DecimalFormat
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF080B14)
private val Panel = Color(0xFF141A29)
private val Muted = Color(0xFF9AA6BC)
private val Mint = Color(0xFF69F0C1)
private val Blue = Color(0xFF7B9CFF)
private val White = Color(0xFFF4F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ajz_tracker", MODE_PRIVATE)
        setContent {
            var weightText by remember { mutableStateOf(prefs.getString("weight", "77.0") ?: "77.0") }
            var targetText by remember { mutableStateOf(prefs.getString("target", "500") ?: "500") }
            var achievedText by remember { mutableStateOf(prefs.getString("achieved", "0") ?: "0") }
            val weight = weightText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            val target = targetText.toIntOrNull()?.coerceAtLeast(1) ?: 500
            val achieved = achievedText.toIntOrNull()?.coerceAtLeast(0) ?: 0
            val progress = (achieved.toFloat() / target.toFloat()).coerceIn(0f, 1f)
            val remaining = max(0, target - achieved)
            val predicted = max(0.0, weight - (achieved.coerceAtMost(10000) / 7700.0))
            val df = DecimalFormat("0.00")

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Mint,
                    secondary = Blue,
                    background = Bg,
                    surface = Panel,
                    onBackground = White,
                    onSurface = White
                )
            ) {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF111A2C), Bg, Color(0xFF080B14)))
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("عَجْزي", color = White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                                Text("كل يوم خطوة أقرب لهدفك", color = Muted, fontSize = 13.sp)
                            }
                            Box(
                                Modifier.size(46.dp).background(Color(0x223DE2B1), CircleShape),
                                contentAlignment = Alignment.Center
                            ) { Text("✦", color = Mint, fontSize = 25.sp) }
                        }

                        Spacer(Modifier.height(28.dp))
                        Text("عجز اليوم", color = Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(12.dp))

                        val animatedProgress by animateFloatAsState(
                            targetValue = progress,
                            animationSpec = spring(dampingRatio = 0.72f, stiffness = 65f),
                            label = "progress"
                        )
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(260.dp)) {
                            Canvas(Modifier.fillMaxSize()) {
                                val stroke = 15.dp.toPx()
                                drawArc(
                                    color = Color(0xFF283247),
                                    startAngle = -90f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = StrokeCap.Round)
                                )
                                drawArc(
                                    brush = Brush.sweepGradient(listOf(Mint, Blue, Mint)),
                                    startAngle = -90f,
                                    sweepAngle = 360f * animatedProgress,
                                    useCenter = false,
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = StrokeCap.Round)
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    if (remaining == 0) "اكتمل الهدف 🎉" else "متبقي",
                                    color = Muted, fontSize = 14.sp
                                )
                                Spacer(Modifier.height(7.dp))
                                Text(
                                    if (remaining == 0) "$achieved" else "$remaining",
                                    color = White, fontSize = 48.sp, fontWeight = FontWeight.Bold
                                )
                                Text("سعرة حرارية", color = Mint, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(8.dp))
                                Text("الهدف $target • أنجزت $achieved", color = Muted, fontSize = 11.sp)
                            }
                        }

                        Spacer(Modifier.height(24.dp))
                        AnimatedVisibility(
                            visible = achieved >= target,
                            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 3 })
                        ) {
                            Surface(
                                color = Color(0xFF172B2B),
                                shape = RoundedCornerShape(22.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.End) {
                                    Text("وزنك المتوقع بكرة", color = Mint, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(5.dp))
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text("كجم", color = Muted, fontSize = 13.sp)
                                        Spacer(Modifier.width(8.dp))
                                        Text(df.format(predicted), color = White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("تقدير حسابي للعجز المُدخل، مش قراءة ميزان فعلية.", color = Muted, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(Modifier.height(22.dp))
                        SectionTitle("بياناتك")
                        Spacer(Modifier.height(10.dp))
                        InputCard(
                            label = "وزنك الحالي (كجم)",
                            value = weightText,
                            onValueChange = { weightText = it; prefs.edit().putString("weight", it).apply() },
                            hint = "مثال: 77.0",
                            keyboard = KeyboardType.Decimal
                        )
                        Spacer(Modifier.height(10.dp))
                        InputCard(
                            label = "العجز المستهدف اليوم (سعرة)",
                            value = targetText,
                            onValueChange = { targetText = it; prefs.edit().putString("target", it).apply() },
                            hint = "مثال: 500",
                            keyboard = KeyboardType.Number
                        )
                        Spacer(Modifier.height(10.dp))
                        InputCard(
                            label = "العجز اللي حققته لحد دلوقتي",
                            value = achievedText,
                            onValueChange = { achievedText = it; prefs.edit().putString("achieved", it).apply() },
                            hint = "مثال: 350",
                            keyboard = KeyboardType.Number
                        )

                        Spacer(Modifier.height(18.dp))
                        Surface(
                            color = Color(0xFF171E2D),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("معلومة مهمة", color = Blue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "الحساب بيستخدم تقدير 7,700 سعرة لكل كجم دهون. تغيّر الميزان الحقيقي ممكن يختلف يوميًا بسبب المياه والأكل والجليكوجين.",
                                    color = Muted, fontSize = 12.sp, lineHeight = 19.sp, textAlign = TextAlign.End
                                )
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("بياناتك محفوظة على الجهاز • الإصدار 1.0", color = Color(0xFF66738A), fontSize = 11.sp)
                        Spacer(Modifier.height(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, modifier = Modifier.fillMaxWidth(), color = White, fontSize = 17.sp,
        fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
}

@Composable
private fun InputCard(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    keyboard: KeyboardType
) {
    Surface(
        color = Panel,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().shadow(3.dp, RoundedCornerShape(18.dp))
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), horizontalAlignment = Alignment.End) {
            Text(label, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(7.dp))
            OutlinedTextField(
                value = value,
                onValueChange = { input ->
                    val filtered = if (keyboard == KeyboardType.Decimal) input.filter { it.isDigit() || it == '.' }
                    else input.filter { it.isDigit() }
                    onValueChange(filtered)
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(hint, color = Color(0xFF657188)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = keyboard),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = White,
                    unfocusedTextColor = White,
                    focusedBorderColor = Mint,
                    unfocusedBorderColor = Color(0xFF354158),
                    cursorColor = Mint,
                    focusedContainerColor = Color(0xFF101625),
                    unfocusedContainerColor = Color(0xFF101625)
                ),
                shape = RoundedCornerShape(13.dp)
            )
        }
    }
}
