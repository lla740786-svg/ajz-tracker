package com.sha3wza.ajztracker

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Ink = Color(0xFF202638)
private val Muted = Color(0xFF7E8798)
private val Mint = Color(0xFF28BFA0)
private val Blue = Color(0xFF7195F5)
private val Page = Color(0xFFF5F7FB)
private val Glass = Color(0xBFFFFFFF)
private val Border = Color(0xFFE6EAF1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val prefs = getSharedPreferences("ajz_tracker", MODE_PRIVATE)
        setContent {
            var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
            var age by remember { mutableStateOf(prefs.getString("age", "") ?: "") }
            var weightText by remember { mutableStateOf(prefs.getString("weight", "77.0") ?: "77.0") }
            var heightText by remember { mutableStateOf(prefs.getString("height", "") ?: "") }
            var goalText by remember { mutableStateOf(prefs.getString("goal", "70.0") ?: "70.0") }
            var targetText by remember { mutableStateOf(prefs.getString("target", "500") ?: "500") }
            var achievedText by remember { mutableStateOf("0") }
            var selectedDay by remember { mutableStateOf(todayKey()) }
            var savedMessage by remember { mutableStateOf("") }
            var profileSaved by remember { mutableStateOf(prefs.getBoolean("profile_saved", false)) }

            val history = remember {
                mutableStateMapOf<String, Int>().apply {
                    val raw = prefs.getString("history", "{}") ?: "{}"
                    try {
                        val json = JSONObject(raw)
                        json.keys().forEach { key -> put(key, json.optInt(key, 0)) }
                    } catch (_: Exception) {}
                    if (!containsKey(todayKey())) {
                        val oldToday = prefs.getInt("achieved", 0)
                        if (oldToday > 0) put(todayKey(), oldToday)
                    }
                }
            }
            val weight = weightText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            val goal = goalText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            val target = targetText.toIntOrNull()?.coerceAtLeast(1) ?: 500
            val achieved = achievedText.toIntOrNull()?.coerceAtLeast(0) ?: 0
            val dayDeficit = history[selectedDay] ?: 0
            val remaining = max(0, target - dayDeficit)
            val predictedTomorrow = max(0.0, weight - (dayDeficit / 7700.0))
            val lost = max(0.0, weight - goal)
            val remainingKg = max(0.0, weight - (history.values.sum() / 7700.0) - goal)
            val progress = (dayDeficit.toFloat() / target.toFloat()).coerceIn(0f, 1f)
            val df = DecimalFormat("0.00")

            MaterialTheme(colorScheme = lightColorScheme(
                primary = Mint, secondary = Blue, background = Page, surface = Color.White,
                onBackground = Ink, onSurface = Ink
            )) {
                Box(Modifier.fillMaxSize().background(Page)) {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                            .padding(horizontal = 18.dp, vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFE4F8F2)),
                                contentAlignment = Alignment.Center) {
                                Text("✦", color = Mint, fontSize = 27.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("عَجْزي", color = Ink, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                                Text("كل يوم خطوة أقرب لهدفك", color = Muted, fontSize = 12.sp)
                            }
                        }

                        Spacer(Modifier.height(18.dp))
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text("اليوم", color = Muted, fontSize = 13.sp)
                                    Text(dateLabel(selectedDay), color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text("‹", color = Blue, fontSize = 34.sp, modifier = Modifier
                                        .clip(CircleShape).clickable {
                                            selectedDay = shiftDay(selectedDay, -1)
                                            achievedText = (history[selectedDay] ?: 0).toString()
                                            savedMessage = ""
                                        }.padding(horizontal = 12.dp))
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("عجز السعرات", color = Muted, fontSize = 13.sp)
                                        Spacer(Modifier.height(5.dp))
                                        val animated by animateFloatAsState(progress, spring(dampingRatio = .72f), label = "ring")
                                        Box(Modifier.size(218.dp), contentAlignment = Alignment.Center) {
                                            Canvas(Modifier.fillMaxSize()) {
                                                val sw = 13.dp.toPx()
                                                drawArc(Border, -90f, 360f, false, style = Stroke(sw, cap = StrokeCap.Round))
                                                drawArc(Brush.sweepGradient(listOf(Blue, Color(0xFF73D5D0), Mint)),
                                                    -90f, 360f * animated, false, style = Stroke(sw, cap = StrokeCap.Round))
                                            }
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(if (dayDeficit >= target) "اكتمل الهدف 🎉" else "متبقي", color = Muted, fontSize = 13.sp)
                                                Text(if (dayDeficit >= target) "$dayDeficit" else "$remaining",
                                                    color = Ink, fontSize = 43.sp, fontWeight = FontWeight.Bold)
                                                Text("سعرة حرارية", color = Mint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                Text("الهدف $target • أنجزت $dayDeficit", color = Muted, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                    Text("›", color = if (selectedDay == todayKey()) Border else Blue,
                                        fontSize = 34.sp, modifier = Modifier.clip(CircleShape).clickable {
                                            if (selectedDay != todayKey()) {
                                                selectedDay = shiftDay(selectedDay, 1)
                                                achievedText = (history[selectedDay] ?: 0).toString()
                                                savedMessage = ""
                                            }
                                        }.padding(horizontal = 12.dp))
                                }
                            }
                        }

                        Spacer(Modifier.height(12.dp))
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(17.dp), horizontalAlignment = Alignment.End) {
                                Text("وزنك المتوقع غدًا", color = Mint, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(5.dp))
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text("كجم", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (profileSaved) df.format(predictedTomorrow) else "احفظ بياناتك أولًا",
                                        color = Ink, fontSize = 31.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("تقدير نظري حسب عجز اليوم المسجل، وليس قراءة فعلية للميزان.",
                                    color = Muted, fontSize = 11.sp)
                            }
                        }

                        Spacer(Modifier.height(15.dp))
                        SectionHeader("تسجيل عجز اليوم")
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
                                AppInput("العجز اللي حققته اليوم (سعرة)", achievedText, { achievedText = it },
                                    "مثال: 450", KeyboardType.Number)
                                Spacer(Modifier.height(10.dp))
                                AppInput("هدف العجز اليومي (سعرة)", targetText, {
                                    targetText = it
                                    prefs.edit().putString("target", it).apply()
                                }, "500", KeyboardType.Number)
                                Spacer(Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        val v = achievedText.toIntOrNull()?.coerceAtLeast(0) ?: 0
                                        history[selectedDay] = v
                                        val obj = JSONObject()
                                        history.forEach { (k, value) -> obj.put(k, value) }
                                        prefs.edit().putString("history", obj.toString()).putString("target", targetText).apply()
                                        savedMessage = "اتحفظ عجز يوم ${dateLabel(selectedDay)} ✓"
                                    },
                                    modifier = Modifier.fillMaxWidth().height(49.dp),
                                    shape = RoundedCornerShape(15.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Mint)
                                ) { Text("حفظ عجز اليوم", color = Color.White, fontWeight = FontWeight.Bold) }
                                if (savedMessage.isNotBlank()) Text(savedMessage, color = Mint,
                                    modifier = Modifier.padding(top = 7.dp), fontSize = 12.sp)
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        SectionHeader("بياناتك الشخصية")
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
                                AppInput("الاسم", name, { name = it }, "اسمك", KeyboardType.Text)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(Modifier.weight(1f)) {
                                        AppInput("السن", age, { age = it }, "مثال: 25", KeyboardType.Number)
                                    }
                                    Box(Modifier.weight(1f)) {
                                        AppInput("الطول (سم)", heightText, { heightText = it }, "مثال: 175", KeyboardType.Decimal)
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(Modifier.weight(1f)) {
                                        AppInput("الوزن المستهدف (كجم)", goalText, { goalText = it }, "70", KeyboardType.Decimal)
                                    }
                                    Box(Modifier.weight(1f)) {
                                        AppInput("وزنك الحالي (كجم)", weightText, { weightText = it }, "77", KeyboardType.Decimal)
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        prefs.edit().putString("name", name).putString("age", age)
                                            .putString("weight", weightText).putString("height", heightText)
                                            .putString("goal", goalText).putBoolean("profile_saved", true).apply()
                                        profileSaved = true
                                        savedMessage = "اتحفظت بياناتك بنجاح ✓"
                                    },
                                    modifier = Modifier.fillMaxWidth().height(49.dp),
                                    shape = RoundedCornerShape(15.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Ink)
                                ) { Text("حفظ بياناتي", color = Color.White, fontWeight = FontWeight.Bold) }
                                if (name.isNotBlank()) Text("أهلًا $name 👋", color = Muted,
                                    modifier = Modifier.padding(top = 7.dp), fontSize = 12.sp)
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        SectionHeader("ملخص آخر 7 أيام")
                        val weekKeys = (6 downTo 0).map { shiftDay(todayKey(), -it) }
                        val weekTotal = weekKeys.sumOf { history[it] ?: 0 }
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(15.dp), horizontalAlignment = Alignment.End) {
                                Text("إجمالي العجز المسجل", color = Muted, fontSize = 12.sp)
                                Text("$weekTotal سعرة", color = Mint, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                weekKeys.forEach { key ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Text("${history[key] ?: 0} سعرة", color = Ink, fontSize = 12.sp)
                                        Text(shortDate(key), color = Muted, fontSize = 12.sp)
                                    }
                                    Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(Color(0xFFE9EDF3))) {
                                        Box(Modifier.fillMaxWidth(((history[key] ?: 0).toFloat() / max(target, 1)).coerceIn(0f,1f))
                                            .fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(Blue, Mint))))
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        SectionHeader("تطور الوزن")
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(15.dp), horizontalAlignment = Alignment.End) {
                                Text(if (profileSaved) "متبقي ${df.format(remainingKg)} كجم للوصول لهدفك" else "احفظ وزنك وهدفك لعرض التقدم",
                                    color = Mint, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(12.dp))
                                val chartWeights = weekKeys.mapIndexed { index, key ->
                                    val cumulative = weekKeys.take(index + 1).sumOf { history[it] ?: 0 }
                                    weight - cumulative / 7700.0
                                }
                                WeightChart(chartWeights)
                                Spacer(Modifier.height(5.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("قبل 6 أيام", color = Muted, fontSize = 10.sp)
                                    Text("اليوم", color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("كل الأرقام تقديرية؛ تغير الماء والهضم قد يؤثر على قراءة الميزان اليومية.",
                            color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(Glass)
        .border(1.dp, Color(0xDDE8EDF4), RoundedCornerShape(24.dp)).animateContentSize(), content = content)
}
@Composable
private fun SectionHeader(text: String) {
    Text(text, Modifier.fillMaxWidth().padding(bottom = 9.dp), color = Ink,
        fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
}
@Composable
private fun AppInput(label: String, value: String, onChange: (String) -> Unit,
                     hint: String, keyboard: KeyboardType) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Text(label, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(
            value = value, onValueChange = { input ->
                onChange(when (keyboard) {
                    KeyboardType.Number -> input.filter { it.isDigit() }
                    KeyboardType.Decimal -> input.filter { it.isDigit() || it == '.' }
                    else -> input
                })
            },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(hint, color = Color(0xFFAAB2BF), fontSize = 13.sp) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = keyboard),
            shape = RoundedCornerShape(15.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Ink, unfocusedTextColor = Ink,
                focusedBorderColor = Mint, unfocusedBorderColor = Border,
                focusedContainerColor = Color(0xFFF9FBFD), unfocusedContainerColor = Color(0xFFF9FBFD),
                cursorColor = Mint
            )
        )
    }
}
@Composable
private fun WeightChart(values: List<Double>) {
    Canvas(Modifier.fillMaxWidth().height(145.dp)) {
        if (values.isEmpty()) return@Canvas
        val minV = (values.minOrNull() ?: 0.0) - 0.08
        val maxV = (values.maxOrNull() ?: 1.0) + 0.08
        val span = (maxV - minV).coerceAtLeast(0.16)
        val points = values.mapIndexed { i, v ->
            Offset(if (values.size == 1) size.width / 2 else i * size.width / (values.size - 1),
                size.height - ((v - minV) / span).toFloat() * (size.height - 20f) - 10f)
        }
        for (i in 0 until 3) {
            val y = i * size.height / 2
            drawLine(Color(0xFFE9EDF3), Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
        }
        for (i in 0 until points.size - 1) {
            drawLine(Brush.linearGradient(listOf(Blue, Mint)), points[i], points[i + 1],
                strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        }
        points.forEach { drawCircle(Mint, 5.dp.toPx(), it); drawCircle(Color.White, 2.dp.toPx(), it) }
    }
}
private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun shiftDay(key: String, amount: Int): String {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val c = Calendar.getInstance()
    c.time = f.parse(key) ?: Date()
    c.add(Calendar.DAY_OF_YEAR, amount)
    return f.format(c.time)
}
private fun dateLabel(key: String): String {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val d = f.parse(key) ?: Date()
    return SimpleDateFormat("EEEE، d MMMM", Locale("ar")).format(d)
}
private fun shortDate(key: String): String {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val d = f.parse(key) ?: Date()
    return SimpleDateFormat("EEE d", Locale("ar")).format(d)
}
